package com.example.gravityimageview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import co.gofynd.gravityview.GravityView;

public class MainActivity extends AppCompatActivity {

    GravityView gravityView;
    ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = (ImageView) findViewById(R.id.image_background);
        gravityView = GravityView.getInstance(this);
        if (!gravityView.deviceSupported())
        {
            Toast.makeText(this,"Device not Support!!!", Toast.LENGTH_SHORT).show();
            return;
        }
        else
        {
            gravityView.setImage(imageView, R.drawable.car)
                    .center();

        }
    }
}